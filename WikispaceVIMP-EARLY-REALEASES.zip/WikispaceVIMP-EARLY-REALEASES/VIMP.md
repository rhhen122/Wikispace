# About VIMP
## VIMP is a foundation that builds and release free open-source code and / software
VIMP is non profit and is looking to on-board more programmers! All programmers are VOLENTEERS!
- For Info about VIMP contact rokyhenderson222@gmail.com
# VIMP's MISSION
## VIMP has a mission! all free software open source!
VIMP loves open-source software SOO MUCH that they make it themselves!
We want to make all free software open-source so that you dont have to pay to not have your info stolen!
