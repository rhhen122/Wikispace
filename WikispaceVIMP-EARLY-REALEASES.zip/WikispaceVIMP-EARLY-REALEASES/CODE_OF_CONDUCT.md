# We Are Open Source and OPEN FOR EVERYONE!
## Redistributing
- Wikispace will NOT TOLERATE redistibuting on a gross level!
- Wikispace is maintained by VIMP (Visual Interface Makers Productive) As apart of this Wikispace is not to be re-used in ANY Malicious
  mannor what so EVER!
- Wikispace is a supporting program of the "Save Palistine Movement" please respect this decision.
## Our Pledge
- As it comes with being open source Wikispace pledges that it will not include any Malicious or Invaseive Code/Software Within ANY OFFICIAL Branch of Wikispace
